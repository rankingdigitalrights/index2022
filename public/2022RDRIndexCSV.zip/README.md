# Readme - 2022 RDR Big Tech Scorecard - Public CSV Dataset

> Last updated: 2022-04-21

## Description

This Zip file contains the final public dataset for the 2022 RDR Big Tech Scorecard in both human-readable and machine-readable formats.

The Ranking Digital Rights 2022 Big Tech Scorecard Index evaluates 14 of the world’s most powerful digital platforms on their commitments, policies, and practices that affect users’ freedom of expression and privacy.

The CSV files include the evaluation and scoring for each indicator and element for the 14 companies, and the accompanying source references.

For a detailed overview of the RDR' methodology please see the Methods and Standards page:

- Methodology: https://rankingdigitalrights.org/methods-and-standards/

More info:

- 2022 RDR Big Tech Scorecard: https://rankingdigitalrights.org/index2022
- RDR Website: https://rankingdigitalrights.org

## File Contents

### Evaluation Results and Scores

#### Overview - wide format

- `2022-rdr-index-01-quick-overview.csv`  
  + overview of Company Totals and Category scores (Governance, Freedom of Expression, Privacy)
- `2022-rdr-index-02-summary-scores.csv`
  + detailed overview of Indicator, and Level scores for each Company and it's ranked services.
  + includes Totals and Indicator Family scores.

#### Detailed Results and Scoring - long format

- `2022-rdr-index-03-total-scores.csv`
  + Total scores for each Company
- `2022-rdr-index-04-indicator-scores.csv`
  + Indicator and Indicator Family scores for each Company
- `2022-rdr-index-05-level-scores.csv`
  + Service level scores and Source document references for each Company and Service
  + all Sources are provided in the respective Company Sources CSV file in `/company-sources/`
- `2022-rdr-index-06-element-scores.csv`
  + Element-level evaluation results ("Answers"), scores, and comments for each Company and Service

### Metadata

- `2022-rdr-index-11-meta-elements.csv`
  + Element-level description / language
  + additional information such as Elements with reversed Scoring scales or Company/Service types for which elements might not apply
- `2022-rdr-index-12-meta-elements.csv`
  + Indicator-level description / language
  + Indicator-level Research Guidance
  + Indicator-specific Scoring scopes and Company types to be excluded for a particular Indicator
  + a Boolean `isParent` to indicate whether an Indicator is a standalone Indicator or an Indicator Family Parent

### Company-Level Sources

- `/company-sources/2022-rdr-index-<Company>-sources.csv`
  + For each company, the subfolder `/company-sources/` contains a file `2022-rdr-index-<Company>-sources.csv`. The sources file lists all sources used for the evaluation of the respective company, including the source reference number in alignment with the `Sources` field in `2022-rdr-index-05-level-scores.csv`.
