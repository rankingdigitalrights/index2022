# Readme - 2020 RDR Index - Public CSV Dataset

> Last updated: 2020-02-24

## Description

This Zip file contains the final public dataset for the 2020 Ranking Digital Rights Corporate Accountability Index in both human-readable and machine-readable formats.

The Ranking Digital Rights 2020 Corporate Accountability Index evaluates 26 of the world’s most powerful digital platform and telecommunications companies on their commitments, policies, and practices that affect users’ freedom of expression and privacy.

The CSV files include the evaluation and scoring for each indicator and element for the 26 companies, and the accompanying source references.

For a detailed overview of the Index' terminology, methodology, and an overview of the ranked Companies and Services please see the detailed Methodology:

- Methodology: https://rankingdigitalrights.org/2020-indicators/

More info:

- 2020 RDR Corporate Accountability Index: https://rankingdigitalrights.org/index2020/
- RDR Website: https://rankingdigitalrights.org

## File Contents

### Evaluation Results and Scores

#### Overview - wide format

- `2020-rdr-index-01-quick-overview.csv`  
  + overview of Company Totals and Category scores (Governance, Freedom of Expression, Privacy)
- `2020-rdr-index-02-summary-scores.csv`
  + detailed overview of Indicator, and Level scores for each Company and it's ranked services.
  + includes Totals and Indicator Family scores as well as aggregate Mobile Service scores for Telecommunication companies

#### Detailed Results and Scoring - long format

- `2020-rdr-index-03-total-scores.csv`
  + Total scores for each Company
- `2020-rdr-index-04-indicator-scores.csv`
  + Indicator and Indicator Family scores for each Company
- `2020-rdr-index-05-level-scores.csv`
  + Service level scores and Source document references for each Company and Service
  + all Sources are provided in the respective Company Sources CSV file in `/company-sources/`
- `2020-rdr-index-06-element-scores.csv`
  + Element-level evaluation results ("Answers"), scores, and comments for each Company and Service

### Metadata

- `2020-rdr-index-11-meta-elements.csv`
  + Element-level description / language
  + additional information such as Elements with reversed Scoring scales or Company/Service types for which elements might not apply
- `2020-rdr-index-12-meta-elements.csv`
  + Indicator-level description / language
  + Indicator-level Research Guidance
  + Indicator-specific Scoring scopes and Company types to be excluded for a particular Indicator
  + a Boolean `isParent` to indicate whether an Indicator is a standalone Indicator or an Indicator Family Parent

### Company-Level Sources

- `/company-sources/2020-rdr-index-<Company>-sources.csv`
  + For each company, the subfolder `/company-sources/` contains a file `2020-rdr-index-<Company>-sources.csv`. The sources file lists all sources used for the evaluation of the respective company, including the source reference number in alignment with the `Sources` field in `2020-rdr-index-05-level-scores.csv`.
